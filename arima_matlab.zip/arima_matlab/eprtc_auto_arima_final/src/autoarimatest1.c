#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ctsa.h"
/*

Auto ARIMA example 1

*/

int main(void) {
	
	FILE *ifp;
	FILE *ifp1;
	double temp[1200];
    int i, N,new_N,mid_N, d= 2, D= 0, L=720;
	double *inp,*x;
	int p =5, q= 5, P= 0, Q= 0, s= 0, r= 0;
	double *xpred, *amse,*xpred_end,*xpred_mid;
	auto_arima_object obj;
	arima_object obj_new;

	int order[3] = {p,d,q};
	int seasonal[3] = {P,D,Q};
	
	xpred = (double*)malloc(sizeof(double)* L);
	xpred_end = (double*)malloc(sizeof(double)* L);
	amse = (double*)malloc(sizeof(double)* L);

	ifp = fopen("../data/k1_jiaxing_0812.txt", "r");
	i = 0;
	if (!ifp) {
		printf("Cannot Open File");
		exit(100);
	}
	while (!feof(ifp)) {
		fscanf(ifp, "%lf\n", &temp[i]);
		i++;
	}
	N = i;
	mid_N = N;
	inp = (double*)malloc(sizeof(double)* N);
	xpred_mid = (double*)malloc(sizeof(double)* (L+N));

	for (i = 0; i < N; ++i) {
		inp[i] = temp[i];
       
	}
	obj = auto_arima_init(order,seasonal,s,r,N);
	auto_arima_setApproximation(obj,0);
	auto_arima_setStepwise(obj,0);

	auto_arima_exec(obj,inp,NULL);

	new_N = N - (obj->d);
	x = (double*)malloc(sizeof(double)* new_N);
	if(obj->d>0){	
		N = diff(inp, N, obj->d, x);
	}
	else{
		for (i = 0; i < N; ++i) {
			x[i] = inp[i];
		}
	}
	obj_new = arima_init(4, 0, 4, new_N);
	arima_exec(obj_new, x);
	arima_summary(obj_new);
	arima_predict(obj_new, x, L, xpred, amse);
	if(obj->d==0){
		for (i = 0; i < L; ++i) {
			xpred_end[i] = xpred[i];
		}
	}
	else if(obj->d==1){
		for (i = 0; i < mid_N; ++i) {
			xpred_mid[i] = inp[i];
		}
		for (i = mid_N; i < mid_N+L; ++i) {
			xpred_mid[i] = xpred[i-mid_N] + xpred_mid[i-1];
		}
		for (i = 0; i < L; ++i) {
			xpred_end[i] = xpred_mid[i+mid_N];
		}
	}
	else{
		for (i = 0; i < mid_N; ++i) {
			xpred_mid[i] = inp[i];
		}
		for (i = mid_N; i < mid_N+L; ++i) {
			xpred_mid[i] =  2*xpred_mid[i-1] - xpred_mid[i-2] + xpred[i-mid_N];
		}
		for (i = 0; i < L; ++i) {
			xpred_end[i] = xpred_mid[i+mid_N];
		}
	}


	

	ifp1 = fopen("../data/k1_jiaxing_0812_pre.txt", "w");

	printf("\n");
	printf("Predicted Values : ");
	
	for (i = 0; i < L; ++i) {
		printf("%g ", xpred_end[i]);
		fprintf(ifp1,"%.20lf\n",xpred_end[i]);
	}

	printf("\n");


	auto_arima_free(obj);
	arima_free(obj_new);

	
	free(inp);
	free(xpred);
	free(amse);
	free(x);
	free(xpred_mid);
	free(xpred_end);
	fclose(ifp);
	fclose(ifp1);
    return 0;
}
