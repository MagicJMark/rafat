function [AR_Order,MA_Order,aicorbic] = ARMA_Order_Select(data,max_ar,max_ma,di,criterion)
if ~exist('criterion')||isempty(criterion) 
    criterion = 'aic+bic';
end
T = length(data);

for ar = 0:max_ar
    for ma = 0:max_ma
        if ar==0&&ma==0
            infoC_Sum = NaN;
            infoC_Log = NaN;
            continue
        end
        try
            Mdl = arima(ar, di, ma);
            [~, ~, LogL] = estimate(Mdl, data, 'Display', 'off');
            [aic,bic] = aicbic(LogL,(ar+ma+2),T); 
            switch criterion
                case 'aic'
                    infoC_Sum(ar+1,ma+1) = aic;  
                    infoC_Log(ar+1,ma+1) = LogL;
                case 'bic'
                    infoC_Sum(ar+1,ma+1) = bic;  
                    infoC_Log(ar+1,ma+1) = LogL;
                case 'aic+bic'
                    infoC_Sum(ar+1,ma+1) = bic+aic;  
                    infoC_Log(ar+1,ma+1) = LogL;
            end
        catch ME 
            msgtext = ME.message;
            if (strcmp(ME.identifier,'econ:arima:estimate:InvalidVarianceModel'))
                 infoC_Sum(ar+1,ma+1) = NaN; 
                
            else
                
                infoC_Sum(ar+1,ma+1) = NaN; 
            end
        end
    end
end
aicorbic = infoC_Sum;  
[x, y]=find(infoC_Sum==min(min(infoC_Sum)));
AR_Order = x -1;
MA_Order = y -1;
end