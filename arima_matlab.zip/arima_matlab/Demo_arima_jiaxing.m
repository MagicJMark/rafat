
clear all;
clc;

% original data
fullname_33 = 'G:\AAA_saisi_2\eprtc\project\eprtc_auto_arima_final\data\k0_jiaxing_0812.txt';
fid_33 = fopen(fullname_33,'r');
file_buf_33 = textscan(fid_33,'%f');
fclose(fid_33);
k0 =file_buf_33{1,1}; 

fullname_44 = 'G:\AAA_saisi_2\eprtc\project\eprtc_auto_arima_final\data\k1_jiaxing_0812.txt';
fid_44 = fopen(fullname_44,'r');
file_buf_44 = textscan(fid_44,'%f');
fclose(fid_44);
k1 =file_buf_44{1,1}; 

% the result of the VS code
fullname_12 = 'G:\AAA_saisi_2\eprtc\project\eprtc_auto_arima_final\data\k0_jiaxing_0812_pre.txt';
fid_12 = fopen(fullname_12,'r');
file_buf_12 = textscan(fid_12,'%f');
fclose(fid_12);
forData1_a0 =file_buf_12{1,1};  

fullname_22 = 'G:\AAA_saisi_2\eprtc\project\eprtc_auto_arima_final\data\k1_jiaxing_0812_pre.txt';
fid_22 = fopen(fullname_22,'r');
file_buf_22 = textscan(fid_22,'%f');
fclose(fid_22);
forData1_a1 =file_buf_22{1,1};  

% the result of the MATLAB code
step = 24*30; 
p_max = 5; 
q_max = 5; 
figflag = 'off'; 
[pre_k0,lower1_a0,upper1_a0,res_a0] = Fun_ARIMA_Forecast(k0,step,p_max,q_max,figflag,'aic');  
[pre_k1,lower1_a1,upper1_a1,res_a1] = Fun_ARIMA_Forecast(k1,step,p_max,q_max,figflag,'aic'); 


figure(1)
plot([k0' pre_k0'],'-*');
hold on;
plot([k0' forData1_a0'],'-s');
legend('data-matlab','data-vs');

figure(2)
plot([k1' pre_k1'],'-*');
hold on;
plot([k1' forData1_a1'],'-s');
legend('data-matlab','data-vs');




